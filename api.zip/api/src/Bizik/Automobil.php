<?php

namespace Bizik;

/**
 * @Entity @Table(name="prodaja_automobila")
 **/


class Automobil
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $automobil;

    /**
    * @Column(type="string")
    */
    private $proizvodac;

    /**
    * @Column(type="string")
    */
    private $kupac;

    /**
    * @Column(type="integer")
    */
    private $cijena;

    /**
    * @Column(type="string")
    */
    private $blagajnik;

  public function getSifra(){
		return $this->sifra;
	}

	public function setSifra($sifra){
		$this->sifra = $sifra;
	}

  public function getAutomobil(){
		return $this->automobil;
	}

	public function setAutomobil($automobil){
		$this->automobil = $automobil;
	}

  public function getProizvodac(){
    return $this->proizvodac;
  }

  public function setProizvodac($proizvodac){
		$this->proizvodac = $proizvodac;
	}

  public function getKupac(){
  	return $this->kupac;
  }

  public function setKupac($kupac){
		$this->kupac = $kupac;
	}

  public function getCijena(){
    return $this->cijena;
  }

  public function setCijena($cijena){
    $this->cijena = $cijena;
  }

  public function getBlagajnik(){
    return $this->blagajnik;
  }

  public function setBlagajnik($blagajnik){
    $this->blagajnik = $blagajnik;
  }

  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
