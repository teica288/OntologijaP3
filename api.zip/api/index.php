<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Bizik\Automobil;
use Composer\Autoload\ClassLoader;

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Bizik\Automobil');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /ispuni', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('http://oziz.ffos.hr/nastava20192020/tbizik_19/ontologija/prodaja_automobila_Bizik_ver2.rdf');


  foreach ($foaf->resources() as $resource) {
    if($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/tbizik/prodaja_automobila#naziv_proizvodaca>') != ''){
      $automobil = $foaf->get($resource, '<http://oziz.ffos.hr/tsw2/tbizik/prodaja_automobila#automobil>');
      $url = parse_url($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/tbizik/prodaja_automobila#naziv_proizvodaca>'));
      $proizvodac = str_replace('_', ' ', $url["fragment"]);
      $kupac = $foaf->get($resource, '<http://oziz.ffos.hr/tbizik/fn-ontologija#kupac>');
      $cijena = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tbizik/fn-ontologija#cijena>');
      $blagajnik = $foaf->get($resource, '<http://oziz.ffos.hr/tbizik/fn-ontologija#blagajnik>');

      $ontologija = new Automobil();
      $ontologija->setPodaci(Flight::request()->data);

      $ontologija->setAutomobil($automobil);
      $ontologija->setProizvodac($proizvodac);
      $ontologija->setKupac($kupac);
      $ontologija->setCijena($cijena);
      $ontologija->setBlagajnik($blagajnik);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($ontologija);
      $em->flush();

    }
  }

});

Flight::route('GET /search/@automobil', function($automobil){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Bizik\Automobil');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.automobil LIKE :automobil')
                        ->setParameter('automobil', '%'.$automobil.'%')
                        ->getQuery()
                        ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Bizik', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();
