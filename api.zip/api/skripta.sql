create database tbizik_19 default character set utf8;
use tbizik_19;
create table prodaja_automobila(
    sifra int not null primary key auto_increment,
    automobil varchar(100) not null,
    proizvodac varchar(100) not null,
    kupac varchar(100) not null,
    cijena int not null,
    blagajnik varchar(100) not null
);
